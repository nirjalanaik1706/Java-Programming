package com.transflower.tflassessment.demo.services;

public interface  PersonService {
    void getAll();
    void getById();
    void insert();
    void update();
    void remove();
    
}
