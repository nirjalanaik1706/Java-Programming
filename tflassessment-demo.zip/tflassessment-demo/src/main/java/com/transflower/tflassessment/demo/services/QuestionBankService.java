package com.transflower.tflassessment.demo.services;

import com.transflower.tflassessment.demo.repositories.*;
public interface QuestionBankService extends QuestionBankRepository {

}
