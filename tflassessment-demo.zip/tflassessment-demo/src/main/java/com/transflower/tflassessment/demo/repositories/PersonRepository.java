package com.transflower.tflassessment.demo.repositories;

public interface PersonRepository {

    void getAll();

    void getById();

    void insert();

    void update();

    void remove();

}
