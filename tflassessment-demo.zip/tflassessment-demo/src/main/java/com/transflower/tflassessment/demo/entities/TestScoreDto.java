package com.transflower.tflassessment.demo.entities;

public class TestScoreDto {
 
    private  String testName ;
    private  int score;

    public String getTestName() {
        return testName;
    }
    public void setTestName(String testName) {
        this.testName = testName;
    }
    public int getScore() {
        return score;
    }
    public void setScore(int score) {
        this.score = score;
    }
}
 
